
package bidimen.pkg02;


public class Bidimen02 {

   
    public static void main(String[] args) {
       String[][] Nombres = new String[3][3];
Nombres[0][0] = "valor 1";
Nombres[0][1] = "valor 2";
Nombres[0][2] = "valor 3";

Nombres[1][0] = "valor 4";
Nombres[1][1] = "valor 5";
Nombres[1][2] = "valor 6";

Nombres[2][0] = "valor 7";
Nombres[2][1] = "valor 8";
Nombres[2][2] = "valor 9";

System.out.println("Valor en la posición (0, 2): " + Nombres[0][2]);

for (int i = 0; i < Nombres.length; i++) {
    for (int j = 0; j < Nombres[i].length; j++) {
        System.out.println("Valor en la posición (" + i + ", " + j + "): " + Nombres[i][j]);
    }
}
    }
    
}
