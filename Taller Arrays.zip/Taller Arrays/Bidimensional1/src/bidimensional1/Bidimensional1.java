
package bidimensional1;

import javax.swing.JOptionPane;


public class Bidimensional1 {

 
    public static void main(String[] args) {
   int tamañoTablero = 5; 
        int filaBarco = (int) (Math.random() * tamañoTablero); 
        int columnaBarco = (int) (Math.random() * tamañoTablero); 
        int intentos = 0; 

        String mensajeBienvenida = "¡Bienvenido al emocionante juego de Batalla Naval!\n"
                + "Tu objetivo es hundir el barco en el menor número de intentos.";

        JOptionPane.showMessageDialog(null, mensajeBienvenida, "Batalla Naval", JOptionPane.INFORMATION_MESSAGE);

        while (true) {
            int filaDisparo = obtenerNumero("Ingresa la fila (0-" + (tamañoTablero - 1) + "):");
            int columnaDisparo = obtenerNumero("Ingresa la columna (0-" + (tamañoTablero - 1) + "):");

            if (filaDisparo == filaBarco && columnaDisparo == columnaBarco) {
                intentos++;
                String mensajeVictoria = "¡Hundiste el barco en " + intentos + " intentos! ¡Ganaste!";
                JOptionPane.showMessageDialog(null, mensajeVictoria, "Victoria", JOptionPane.WARNING_MESSAGE);
                break;
            } else {
                intentos++;
                String mensajeFallido = "Intento fallido. Sigue intentando.";
                JOptionPane.showMessageDialog(null, mensajeFallido, "Intento Fallido", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    public static int obtenerNumero(String mensaje) {
        String input = JOptionPane.showInputDialog(mensaje);
        return Integer.parseInt(input);
    }
    
}
