
package uni.pkg01;


public class Uni01 {

   
    public static void main(String[] args) {
        String[]Nombres={"stiven","santigo","kevin","juan","manuel"};
        System.out.println("cantidad de nombre: "+Nombres.length);
        System.out.println("el nombre en la posicion 0 es :"+Nombres[0]);
        for(int indice=0;indice<Nombres.length;indice++){
            System.out.println("posicion: "+ indice + " nombres: "+ Nombres[indice]);
            
        }
    }
        
}    
        
    

