
package tridimensional2;

import java.awt.BorderLayout;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class Tridimensional2 {

   
    public static void main(String[] args) {
        // Definir las dimensiones de los arreglos
        int numSucursales = 1;
        int numDepartamentos = 2;
        int numVendedores = 2;
        int numDiasSemana = 3;

        // Crear el arreglo de ventas
        double[][][][] ventas = new double[numSucursales][numDepartamentos][numVendedores][numDiasSemana];

        // Crear un DefaultTableModel para la tabla
        DefaultTableModel modeloTabla = new DefaultTableModel();
        modeloTabla.addColumn("Sucursal");
        modeloTabla.addColumn("Departamento");
        modeloTabla.addColumn("Vendedor");
        modeloTabla.addColumn("Día");
        modeloTabla.addColumn("Venta");

        // Llenar el modelo con los datos de ventas y agregar espacio entre sucursales
        for (int sucursal = 1; sucursal <= numSucursales; sucursal++) {
            for (int departamento = 1; departamento <= numDepartamentos; departamento++) {
                for (int vendedor = 1; vendedor <= numVendedores; vendedor++) {
                    for (int dia = 1; dia <= numDiasSemana; dia++) {
                        String input = JOptionPane.showInputDialog(
                                "Ingrese la venta para Sucursal " + sucursal +
                                ", Departamento " + departamento +
                                ", Vendedor " + vendedor +
                                ", Día " + dia
                        );

                        try {
                            double venta = Double.parseDouble(input);
                            ventas[sucursal - 1][departamento - 1][vendedor - 1][dia - 1] = venta;
                            Object[] fila = {sucursal, departamento, vendedor, dia, venta};
                            modeloTabla.addRow(fila);
                        } catch (NumberFormatException e) {
                            JOptionPane.showMessageDialog(null, "Ingrese un número válido.");
                            dia--; // Repetir el mismo día
                        }
                    }
                }
                if (departamento < numDepartamentos) {
                    // Agregar una fila vacía como espacio entre departamentos
                    modeloTabla.addRow(new Object[]{"", "", "", "", ""});
                }
            }
            if (sucursal < numSucursales) {
                // Agregar una fila vacía como espacio entre sucursales
                modeloTabla.addRow(new Object[]{"", "", "", "", ""});
            }
        }

        // Crear la tabla JTable y mostrarla en una ventana
        JTable tabla = new JTable(modeloTabla);
        JScrollPane scrollPane = new JScrollPane(tabla);

        JFrame frame = new JFrame("Registro de Ventas");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(new BorderLayout());
        frame.add(scrollPane, BorderLayout.CENTER);
        frame.setSize(800, 600);
        frame.setVisible(true);
        
    }
    
}
