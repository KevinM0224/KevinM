
package tridimensionales1;


import java.awt.Dimension;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;

import javax.swing.table.DefaultTableModel;




public class Tridimensional_27 {

  
    public static void main(String[] args) {
     
       // Definir las dimensiones de la matriz tridimensional
        int numSucursales = 2;
        int numDepartamentos = 2;
        int numDiasSemana = 7;

        // Crear la matriz tridimensional para almacenar los datos de ventas
        double[][][] ventas = new double[numSucursales][numDepartamentos][numDiasSemana];

        // Leer los datos de ventas usando JOptionPane y llenar la matriz
        for (int sucursal = 0; sucursal < numSucursales; sucursal++) {
            for (int departamento = 0; departamento < numDepartamentos; departamento++) {
                for (int dia = 0; dia < numDiasSemana; dia++) {
                    String input = JOptionPane.showInputDialog(
                            "Ingrese la venta para la Sucursal " + (sucursal + 1)
                                    + ", Departamento " + (departamento + 1)
                                    + ", Día " + (dia + 1));
                    try {
                        ventas[sucursal][departamento][dia] = Double.parseDouble(input);
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Entrada inválida. Ingrese un número.");
                        dia--; 
                    }
                }
            }
        }

        // Crear una tabla para mostrar los datos de ventas
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn(""); // Columna vacía para espaciar los días
        model.addColumn(""); // Columna vacía para espaciar los días

        // Agregar las columnas a la tabla para los departamentos
        for (int departamento = 0; departamento < numDepartamentos; departamento++) {
            model.addColumn("Depto. " + (departamento + 1));
        }

        // Agregar los datos de ventas al modelo de la tabla
        for (int sucursal = 0; sucursal < numSucursales; sucursal++) {
            for (int dia = 0; dia < numDiasSemana; dia++) {
                // Crear un array para almacenar los datos de ventas de esta fila
                Object[] rowData = new Object[numDepartamentos + 2];
                rowData[0] = "Sucursal " + (sucursal + 1);
                rowData[1] = "Día " + (dia + 1);

                for (int departamento = 0; departamento < numDepartamentos; departamento++) {
                    rowData[departamento + 2] = ventas[sucursal][departamento][dia];
                }

                model.addRow(rowData);
            }
            // Agregar una fila vacía para separar los días
            if (sucursal < numSucursales - 1) {
                model.addRow(new Object[]{});
            }
        }

        JTable table = new JTable(model);

       

        // Establecer el tamaño preferido de la tabla y agregarla a un JScrollPane
        table.setPreferredScrollableViewportSize(new Dimension(800, 400));
        JScrollPane scrollPane = new JScrollPane(table);

        // Mostrar la tabla en un cuadro de diálogo
        JFrame frame = new JFrame("Datos de Ventas");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(scrollPane);
        frame.pack();
        frame.setVisible(true);
    }
    
}
