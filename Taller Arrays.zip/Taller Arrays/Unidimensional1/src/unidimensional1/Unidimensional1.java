
package unidimensional1;

import javax.swing.JOptionPane;


public class Unidimensional1 {

   
    public static void main(String[] args) {
        
        int[] arreglo = new int[15];

        
        for (int i = 0; i < 15; i++) {
            String input = JOptionPane.showInputDialog("Introduce el número " + (i + 1));
            arreglo[i] = Integer.parseInt(input);
        }

     
        JOptionPane.showMessageDialog(null, "Arreglo original: " + arrayToString(arreglo));

        
        int opcion = JOptionPane.showConfirmDialog(null, "¿Deseas introducir un nuevo número en lugar de uno existente?", "Confirmar", JOptionPane.YES_NO_OPTION);
        if (opcion == JOptionPane.YES_OPTION) {
           
            
            String nuevoNumeroStr = JOptionPane.showInputDialog("Introduce el nuevo número:");
            int nuevoNumero = Integer.parseInt(nuevoNumeroStr);

          
            String indiceStr = JOptionPane.showInputDialog("Introduce el índice del elemento a cambiar (1-15):");
            int indice = Integer.parseInt(indiceStr) - 1;

          
            arreglo[indice] = nuevoNumero;

         
            JOptionPane.showMessageDialog(null, "Arreglo después del cambio: " + arrayToString(arreglo));
        } else {
            JOptionPane.showMessageDialog(null, "No se realizaron cambios en el arreglo.");
        }
    }


    public static String arrayToString(int[] arr) {
        String result = "[";
        for (int i = 0; i < arr.length; i++) {
            result += arr[i];
            if (i < arr.length - 1) {
                result += ", ";
            }
        }
        result += "]";
        return result;
    }
    
}
