import java.util.Scanner;

public class ContadorNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
     
        int[] numeros = new int[25];

        for (int i = 0; i < 25; i++) {
            System.out.print("Ingrese un numero: ");
            numeros[i] = scanner.nextInt();
        }

        int cantidadCero = 0;
        int cantidadAbajoDeCero = 0;
        int cantidadArribaDeCero = 0;

        for (int i = 0; i < 25; i++) {
            if (numeros[i] == 0) {
                cantidadCero++;
            } else if (numeros[i] < 0) {
                cantidadAbajoDeCero++;
            } else {
                cantidadArribaDeCero++;
            }
        }

        System.out.print("Arreglo: [");
        for (int i = 0; i < 25; i++) {
            System.out.print(numeros[i]);
            if (i < 24) {
                System.out.print(", ");
            }
        }
        System.out.println("]");
    
        System.out.println("Cantidad de numeros igual a cero: " + cantidadCero);
        System.out.println("Cantidad de numeros por debajo de cero: " + cantidadAbajoDeCero);
        System.out.println("Cantidad de numeros por encima de cero: " + cantidadArribaDeCero);
        
    }
}
