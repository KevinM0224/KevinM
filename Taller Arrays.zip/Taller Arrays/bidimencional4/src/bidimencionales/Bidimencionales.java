
package bidimencionales;


public class Bidimencionales {

    
    public static void main(String[] args) {
        int[][] enteros = new int[2][3];
        
        enteros[0][0] = 1;
        enteros[0][1] = 2;
        enteros[0][2] = 3;
        enteros[1][0] = 4;
        enteros[1][1] = 5;
        enteros[1][2] = 6;
        for (int i = 0; i < enteros.length; i++) {
    for (int j = 0; j <enteros[i].length; j++) {
        System.out.print(enteros[i][j] + " ");
    }
    System.out.println();
}
        
    }
    
}
