import java.util.Scanner;
import java.util.Arrays;

public class OrdenarNumeros {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int[] numeros = new int[50];

        for (int i = 0; i < 50; i++) {
            System.out.print("Ingrese un numero: ");
            numeros[i] = scanner.nextInt();
        }

        Arrays.sort(numeros);
        
        System.out.println("Numeros en orden de mayor a menor:");
        for (int i = 49; i >= 0; i--) {
            System.out.println(numeros[i]);
        }
    }
}