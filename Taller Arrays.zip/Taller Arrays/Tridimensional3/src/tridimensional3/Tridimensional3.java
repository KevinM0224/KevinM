
package tridimensional3;

import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class Tridimensional3 {

    
    public static void main(String[] args) {
      
        int[][][] ventas = {
                // Sucursal 1
                {
                    {100, 120, 80}, // Enero: Producto A, Producto B, Producto C
                    {90, 110, 75},  // Febrero
                    {110, 130, 85}  // Marzo
                },
                // Sucursal 2
                {
                    {120, 110, 90}, // Enero
                    {95, 105, 70},  // Febrero
                    {115, 125, 80}  // Marzo
                }
        };

      
        DefaultTableModel model = new DefaultTableModel();

      
        model.addColumn("Sucursal");
        model.addColumn("Mes");
        model.addColumn("Producto");
        model.addColumn("Ventas");

        
        for (int sucursal = 0; sucursal < ventas.length; sucursal++) {
            for (int mes = 0; mes < ventas[sucursal].length; mes++) {
                for (int producto = 0; producto < ventas[sucursal][mes].length; producto++) {
                    model.addRow(new Object[]{sucursal + 1, obtenerNombreMes(mes), obtenerNombreProducto(producto), ventas[sucursal][mes][producto]});
                }
            }
        }

       
        JTable table = new JTable(model);

       
        JOptionPane.showMessageDialog(null, new JScrollPane(table), "Seguimiento de Ventas", JOptionPane.PLAIN_MESSAGE);
    }

   
    private static String obtenerNombreMes(int mes) {
        String[] nombresMeses = {"Enero", "Febrero", "Marzo"};
        return nombresMeses[mes];
    }

  
    private static String obtenerNombreProducto(int producto) {
        String[] nombresProductos = {"Producto A", "Producto B", "Producto C"};
        return nombresProductos[producto];
        
        
      
        
        
    }
    
}
