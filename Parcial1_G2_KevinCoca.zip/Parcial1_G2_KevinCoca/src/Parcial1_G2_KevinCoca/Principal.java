
package Parcial1_G2_KevinCoca;


import java.util.Arrays;
import javax.swing.JOptionPane;


public class Principal {

   
    public static void main(String[] args) {
       
        
        double[][] notas = { 
 {90.5, 85.0, 92.0, 88.5}, // Notas del Estudiante 1 
 {78.0, 88.5, 92.5, 76.0}, // Notas del Estudiante 2 
 {85.5, 89.0, 93.0, 91.5} // Notas del Estudiante 3 
};
        
        
        while (true) {
    int opcion = Integer.parseInt(JOptionPane.showInputDialog(null, """
                                                                    1. Calcular el promedio de notas
                                                                    2. Encontrar la nota maxima
                                                                    3. Intercambiar notas de los estudiantes
                                                                    4. mostrar la matriz de notas
                                                                    5. Salir""",
        "Menú de Notas Escolares",
         JOptionPane.ERROR_MESSAGE
    ));

   
    if (opcion == 5) {
        break;
    }

  
    switch (opcion) {
        case 1 -> {
            
            
            for (int i = 0; i < notas.length; i++) {
    double suma = 0;
    for (int j = 0; j < notas[i].length; j++) {
        suma += notas[i][j];
    }
    double promedio = suma / notas[i].length;
    JOptionPane.showMessageDialog(null, "El promedio del estudiante " + (i+1) + " es: " + promedio,"Promedio de notas de los estudiantes",JOptionPane.WARNING_MESSAGE);
  
}
            
            
               }
        case 2 -> {
            
            
            double NotaM = Double.MIN_VALUE;

for (int i = 0; i < notas.length; i++) {
    for (int j = 0; j < notas[i].length; j++) {
        if (notas[i][j] > NotaM) {
            NotaM = notas[i][j];
        }
    }
}

  JOptionPane.showMessageDialog(null, "La nota máxima es: " + NotaM,"Nota maxima",JOptionPane.WARNING_MESSAGE);

           
               }
        case 3 -> {
            
            
   String estudiante1String = JOptionPane.showInputDialog(null,"Ingrese el número del primer estudiante (1-3):","INTERCAMBIO DE NOTAS",JOptionPane.WARNING_MESSAGE);
int estudiante1 = Integer.parseInt(estudiante1String) - 1;

String estudiante2String = JOptionPane.showInputDialog(null,"Ingrese el número del segundo estudiante (1-3):","INTERCAMBIO DE NOTAS",JOptionPane.WARNING_MESSAGE);
int estudiante2 = Integer.parseInt(estudiante2String) - 1;

double[] Temp = notas[estudiante1];
notas[estudiante1] = notas[estudiante2];
notas[estudiante2] = Temp;

String info = "Notas del estudiante 1: " + Arrays.toString(notas[0]) + "\n" +
             "Notas del estudiante 2: " + Arrays.toString(notas[1]) + "\n" +
             "Notas del estudiante 3: " + Arrays.toString(notas[2]);
        JOptionPane.showMessageDialog(null, info,"INTERCAMBIO DE NOTAS",JOptionPane.WARNING_MESSAGE);
        
        }
        
       case 4 ->{
            
  String info = "Notas del estudiante 1: " + Arrays.toString(notas[0]) + "\n" +
             "Notas del estudiante 2: " + Arrays.toString(notas[1]) + "\n" +
             "Notas del estudiante 3: " + Arrays.toString(notas[2]);
        JOptionPane.showMessageDialog(null, info,"NOTAS DE LOS ESTUDIANTES",JOptionPane.WARNING_MESSAGE);
        
       
    
        
        }
        default -> JOptionPane.showMessageDialog(null, "Opción no válida. Por favor, elija una opción válida.");
    }
}
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }
    
}
